CREATE TRIGGER trg_LimitStaffToOneInProgress
    ON Appointment
    AFTER INSERT, UPDATE
    AS
BEGIN
    IF EXISTS (
        SELECT 1
        FROM Appointment a1
                 JOIN inserted i ON a1.staffID = i.staffID
        WHERE a1.status = 'Đang làm'
          AND i.status = 'Đang làm'
          AND a1.appointmentID != i.appointmentID
    )
        BEGIN
            RAISERROR('Nhân viên này đang xử lý một đơn khác!', 16, 1);
            ROLLBACK;
        END
END;
go

